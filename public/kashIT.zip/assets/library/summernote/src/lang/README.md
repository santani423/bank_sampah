Languages
=========

This directory contains translated text messages of Summernote.

`summernote-en-US.js` is the base file of other language files.

If you want to add a language for a new locale, duplicate the base file and name it as `summernote-<locale>.js`.
